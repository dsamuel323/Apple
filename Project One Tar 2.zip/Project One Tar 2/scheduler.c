/**
 *
 * File             : scheduler.c
 * Description      : This is a stub to implement all your scheduling schemes
 *
 * Author(s)        : @author
 * Last Modified    : @date
*/

// Include Files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <assert.h>
#include <time.h>
#include <math.h>
#include <stdbool.h>
#include <math.h>
#include <pthread.h>

void init_scheduler( int sched_type );
int schedule_me( float currentTime, int tid, int remainingTime, int tprio );
int num_preemeptions(int tid);
float total_wait_time(int tid);

#define FCFS    0
#define SRTF    1
#define PBS     2
#define MLFQ    3


struct _thread_info
{
  int id;
  float arrival_time;
  float current_time;
  int required_time;
  int priority;
  int time_quanta_left;
};
typedef struct _thread_info _thread_info_t;

struct node {
  _thread_info_t *t;
  pthread_cond_t *restrict cond;
  struct node *next;
};
typedef struct node node_t;

// Global Mutexes
pthread_mutex_t *restrict scheduler;
pthread_mutex_t *restrict waiting_count;
pthread_mutex_t *restrict thread_on_cpu;

// the READY_QUEUE
node_t *ready_queue;

// multilevel feedback queue
node_t *mlfq[5];


//node_t *ready_queue;
node_t *node_on_cpu = NULL;
int tid_on_cpu = -1;   // the ID of the thread that most recently ran on
                       //   the CPU
int level_on_cpu = 0;  // Priority level of thread running on CPU
                       //   doesn't matter unless using MLFQ
int num_waiting = 0;   // number of threads waiting to add themselves to
                       //   the ready queue
int sched_type;        // type of scheduling logic (0-3)
int global_time = -1;  // global time as tracked by the scheduler

void print_queue(node_t *queue, char *queue_title, char *space)
{
  //  fprintf(stderr, "elsewhere");
  node_t *n = queue->next;

  fprintf(stderr, "%s%s:\n", space, queue_title);
  if (n == NULL) {
    //    fprintf(stderr, "there");
    fprintf(stderr, "%s%s(empty)\n", space, space);
  }
  else {
    //    fprintf(stderr, "here");
    while (n != NULL) {
      fprintf(stderr, "%s%sT%d -- A: %f, C: %f, R: %d, P: %d, Q: %d\n",
              space, space,
              n->t->id, n->t->arrival_time, n->t->current_time,
              n->t->required_time, n->t->priority, n->t->time_quanta_left);
      n = n->next;
    }
  }
}

//const index_to_digit_difference = 49;
void print_ready_queue()
{
  if (sched_type < 3) {
    // Just print the ready queue
    char *title = "Ready Queue";
    char *space = "  ";
    print_queue(ready_queue, title, space);
  }
  else {
    // Print each level of the mlfq
    char *level_title = "Level #";
    char *space = "  ";
    for (int i = 0; i < 5; i++) {
      //level_title[6] = (char)(i + index_to_digit_difference);
      print_queue(mlfq[i], level_title, space);
    }
  }

}


_thread_info_t *
make_thread(float currentTime, int tid, int requiredTime, int tprio)
{
  _thread_info_t *t = (_thread_info_t *) malloc(sizeof(_thread_info_t));
  if (t == NULL) {
    fprintf(stderr,"Error: not enough memory for new thread.\n");
    exit(1);
  }

  t->id = tid;
  t->arrival_time = currentTime;
  t->current_time = currentTime;
  t->required_time = requiredTime;
  t->priority = tprio;
  t->time_quanta_left = 5;

  return t;
}

node_t * new_node()
{
  node_t *n =  (node_t *) malloc(sizeof(node_t));
  if (n == NULL) {
    fprintf(stderr,"Error: not enough memory for new node");
    exit(1);
  }

  n->t = NULL;
  n->cond = NULL;
  n->next = NULL;

  return n;
}






















void init_scheduler( int sched_type ) {
/**

	Fill your code here
*/
if (DEBUG)
  fprintf(stderr, "init_scheduler() called.\n");

sched_type = type;

if (sched_type < 3)
  {
    ready_queue = new_node();
  }
else
  {
    for (int i = 0; i < 5; i++) {
      mlfq[i] = new_node();
    }
  }

// Allocate for global mutexes
scheduler = (pthread_mutex_t *) malloc(sizeof(pthread_mutex_t));
waiting_count = (pthread_mutex_t *) malloc(sizeof(pthread_mutex_t));
thread_on_cpu = (pthread_mutex_t *) malloc(sizeof(pthread_mutex_t));
if (DEBUG)
  fprintf(stderr, "Allocated for global mutexes.\n");

// Initialize global mutexes
pthread_mutex_init(scheduler, NULL);
pthread_mutex_init(waiting_count, NULL);
pthread_mutex_init(thread_on_cpu, NULL);
if (DEBUG)
  fprintf(stderr, "Global mutexes initalized.\n");

}



void cond_errcheck(int result)
{
  if (result > 0)
    {
      puts(strerror(result));
      exit(1);
    }
}

// Atomically sets the thread id for the thread that
// is about to run, or has just run, on the CPU.
void set_thread_on_cpu(int tid)
{
  pthread_mutex_lock(thread_on_cpu);
  tid_on_cpu = tid;
  pthread_mutex_unlock(thread_on_cpu);
}

bool thread_is_on_cpu(int tid)
{
  bool on_cpu;

  pthread_mutex_lock(thread_on_cpu);
  on_cpu = (tid == tid_on_cpu) ? true : false;
  pthread_mutex_unlock(thread_on_cpu);

  return on_cpu;
}


// Associate node n with thread t and make a new cond for
//   signaling the current thread
// Quit on error when making new pthread_cond_t
void init_node_with_thread(node_t *n, _thread_info_t *t)
{
      n->t = t;

      // Allocate for and initialize the node's cond
      n->cond = (pthread_cond_t *) malloc(sizeof(pthread_cond_t));
      int result = pthread_cond_init(n->cond, NULL);

      // If error, quit
      cond_errcheck(result);

      n->next = NULL;
}

node_t * new_node_with_thread(_thread_info_t *t)
{
  node_t *n = new_node();
  init_node_with_thread(n, t);
  return n;
}

void insert_node_at_next(node_t *n, node_t *node_to_insert)
{
  // Save the original next-node
  node_t *original_next = n->next;

  // Make n's next the node we want to insert
  n->next = node_to_insert;

  // Make the inserted node's next-node the original next-node
  n->next->next = original_next;
}

// Determine if node1 should precede node2 in the ready queue.
// Rules determining ordering depend on the scheduling strategy used.
bool node1_goes_before_node2_in_queue(node_t *node1, node_t *node2)
{
  if (sched_type == 0 || sched_type == 3) {
    // For FCFS, we always sort by arrival time
    if (node2->t->arrival_time > node1->t->arrival_time)
      return true;
  }
  else if (sched_type == 1) {
    // For SRTF, we sort first by remaining time and second by
    // reported current_time
    if (node2->t->required_time > node1->t->required_time)
      return true;
    else if (node2->t->required_time == node1->t->required_time) {
      // If the required times are equal, compare by reported current time
      // Lowest current time has priority
      if (node2->t->current_time >= node1->t->current_time)
        return true;
    }
  }
  else if (sched_type == 2) {
    // For PBS, we sort first by thread priority and second by
    // reported current_time
    if (node2->t->priority > node1->t->priority)
      return true;
    else if (node2->t->priority == node1->t->priority) {
      // If the thread priorities are equal, compare by reported current time
      // Lowest current time has priority
      if (node2->t->current_time >= node1->t->current_time)
        return true;
    }
  }
  // -- PROBABLY REMOVE ME --
  else if (sched_type == 3) {
    // For MLFQ, we sort by arrival time (FCFS), unless on last level
    if (node1->t->priority < 3)
    {
      if (node2->t->arrival_time > node1->t->arrival_time)
        return true;
    } else {
      // If node is on last level of priority, use round-robin scheduling
      // (just add to end of queue)
      return false;
    }
  }

  return false;
}

// Insert node node_to_insert into queue
void insert_node_into_ready_queue(node_t *queue, node_t *node_to_insert)
{
  if (queue->next == NULL) {
    // If the ready_queue is empty, put the new thread at the head.
    queue->next = node_to_insert;
    node_to_insert->next = NULL;
    if (DEBUG)
      fprintf(stderr, "Queue was empty, T%d now at head.\n",
              node_to_insert->t->id);
  } else {
    // Otherwise, begin iterating through the queue.
    node_t *n = queue->next;
    node_t *prev = queue;

    // Loop until we
    //  (a) reach the end of the list (n == NULL), or
    //  (b) find a node that should fall BEHIND node_to_insert
    //        in the ready queue, at which point we break
    do {
      if (node1_goes_before_node2_in_queue(node_to_insert, n))
          break;

      prev = n;
      n = n->next;
    } while (n != NULL);

    if (n == NULL) {
      // If n == NULL, we've found the end of the list
      prev->next = node_to_insert;
      prev->next->next = NULL;
    } else {
      // Otherwise, insert node_to_insert
      // and shift the other node backward
      insert_node_at_next(prev, node_to_insert);
    }
  }
}


bool head_of_mlfq_level_has_no_time_quanta_remaining(int level)
{
  if (mlfq[level]->next->t->time_quanta_left == 0)
    return true;
  else
    return false;
}

// Add 1 to the count of threads waiting to be added to the
// READY queue
void inc_waiting()
{
    pthread_mutex_lock(waiting_count);
    num_waiting++;

    if (DEBUG)
      fprintf(stderr, "%d threads to add to queue.\n", num_waiting);

    pthread_mutex_unlock(waiting_count);
}


void pop_queue(node_t *queue)
{
  free(queue->next->t);

  int result = pthread_cond_destroy(queue->next->cond);
  cond_errcheck(result);

  free(queue->next->cond);

  queue->next = queue->next->next;
}

node_t * pop_queue_no_deallocation(node_t *queue)
{
  node_t *n = queue->next;
  queue->next = queue->next->next;
  return n;
}

// Insert n into the queue with priority level
void insert_node_at_level_mlfq(node_t *n, int level)
{
  insert_node_into_ready_queue(mlfq[level], n);
}

// Move n to the next lowest priority queue in the mlfq
// Does no checking to ensure the current level is not 4,
//   i.e. program will crash if you do not wrap this in
//        appropriate logic
void move_node_to_next_level_mlfq(node_t *n)
{
  n->t->priority++;

  int next_level = n->t->priority;

  // Starting time quanta for a level is always
  // five times the level's priority.  To get the
  // "real" priority for a thread we add 1 to its
  // reported priority.
  n->t->time_quanta_left = 5 * (next_level + 1);

  // Semantically, the "level" we're moving the node to is
  // really the target queue's index plus 1
  if (DEBUG == 1)
    fprintf(stderr, "Moving T%d to level %d\n", n->t->id, next_level+1);

  insert_node_at_level_mlfq(n, next_level);
}

node_t * add_new_thread_to_queue(_thread_info_t *t)
{
  if (DEBUG) {
    fprintf(stderr, "Adding T%d to queue.\n", t->id);
  }

  node_t *node_to_insert = new_node_with_thread(t);

  if (sched_type < 3) {
    // Insert node into ready queue
    if (DEBUG) {
      fprintf(stderr, "Inserting T%d according to ", t->id);

      if (sched_type == 0)
        fprintf(stderr, "arrival time.\n");
      else if (sched_type == 1)
        fprintf(stderr, "shortest remaining time.\n");
      else
        fprintf(stderr, "priority.\n");
    }

    insert_node_into_ready_queue(ready_queue, node_to_insert);
  } else {
    if (DEBUG)
      fprintf(stderr, "Inserting T%d into level 1 of MLFQ.\n", t->id);

    // All threads begin at the highest priority level
    node_to_insert->t->priority = 0;

    // Threads in the top level of the MLFQ start with 5 time quanta
    node_to_insert->t->time_quanta_left = 5;
    insert_node_at_level_mlfq(node_to_insert, 0);
  }

  return node_to_insert;
}

// Use only with MLFQ, otherwise debug output makes no sense
void insert_node_at_end_of_queue(node_t *queue, node_t *node_to_insert)
{
  // We assume the correct level has already been set
  if (DEBUG_QUEUE) {
    fprintf(stderr, "Inserting T%d at end of level %d queue.\n",
            node_to_insert->t->id, node_to_insert->t->priority + 1);
  }

  // Find the end of the queue
  node_t *prev = queue;
  node_t *n = queue->next;
  while (n != NULL) {
    prev = n;
    n = n->next;
  }

  // Reattach former head of the queue
  // as new tail of the queue
  prev->next = node_to_insert;

  // Always nullify tail's next pointer
  prev->next->next = NULL;
}

pthread_cond_t *
reinsert_head_of_level_mlfq(int level)
{
  node_t *node_to_reinsert = pop_queue_no_deallocation(mlfq[level]);

  if (DEBUG) {
    fprintf(stderr, "  T%d still has %d time remaining.\n",
            node_to_reinsert->t->id, node_to_reinsert->t->required_time);
  }

  pthread_cond_t *cond = node_to_reinsert->cond;

  //  node_to_reinsert->t-q>time_quanta_left = ((node_to_reinsert->t->priority + 2) * 5);

  if (level < 4) {
    // If we are not yet at the lowest level of the MLFQ,
    // reinsert node at next lowest level of MLFQ
    move_node_to_next_level_mlfq(node_to_reinsert);
  }  else {
    // If at the lowest level of mlfq,
    // Move node to end of lowest level (round robin style)
    node_to_reinsert->t->time_quanta_left = 25;
    insert_node_at_end_of_queue(mlfq[4], node_to_reinsert);
  }

  return cond;
}


// Pop the head of the queue and reinsert it at its correct position
// according to the current schedule type
node_t *
reinsert_head_into_queue(float currentTime, int remainingTime)
{
  pthread_cond_t *cond;
  node_t *node_to_reinsert;
  // No need to reinsert head if FCFS, so we implement no logic for it here.
  // The cond we seek is simply the cond at the head of the ready queue
  if (sched_type == 0) {
    // Update remaining time and current time
    node_to_reinsert = ready_queue->next;
    node_to_reinsert->t->required_time = remainingTime;
    node_to_reinsert->t->current_time = currentTime;

    if (DEBUG)
      fprintf(stderr, "T%d has %d time remaining.\n",
              node_to_reinsert->t->id, node_to_reinsert->t->required_time);

    cond = node_to_reinsert->cond;
  }
  // Otherwise, reinsert based on rules given by schedule type
  else if (sched_type < 3) {
    // Reinsertion for SRTF and PBS is more or less the same
    if (DEBUG)
      fprintf(stderr, "Reinserting T%d into queue.\n",
              node_to_reinsert->t->id);

    node_to_reinsert = pop_queue_no_deallocation(ready_queue);
    node_to_reinsert->t->required_time = remainingTime;
    node_to_reinsert->t->current_time = currentTime;

    if (DEBUG)
      fprintf(stderr, "T%d has %d time remaining.\n",
              node_to_reinsert->t->id, node_to_reinsert->t->required_time);

    cond = node_to_reinsert->cond;
    insert_node_into_ready_queue(ready_queue, node_to_reinsert);

  } else {
    // Otherwise, we're using MLFQ
    int level = node_on_cpu->t->priority;
    node_to_reinsert = mlfq[level]->next;
    cond = node_to_reinsert->cond;

    // Update thread info
    node_to_reinsert->t->required_time = remainingTime;
    node_to_reinsert->t->current_time = currentTime;
    (node_to_reinsert->t->time_quanta_left)--;


    if (head_of_mlfq_level_has_no_time_quanta_remaining(level)) {
      // If thread is out of time quanta, need to reinsert thread at
      // next lowest level of MLFQ
      if (DEBUG)
        fprintf(stderr, "T%d has no quanta remaining at level %d\n",
                node_to_reinsert->t->id, level+1);
      cond = reinsert_head_of_level_mlfq(level);
    }
    // If the thread still has time quanta at this level,
    // we do nothing
  }

  return node_to_reinsert;
}

// Returns a pointer to the node next up on the CPU.
// Returns a NULL pointer if the data structure is empty.
node_t * node_next_on_cpu()
{
  if (sched_type < 3)
    // If we're using FCFS, SRTF, or PBS, the next thread
    // to run on the CPU is the head of ready_queue
    return ready_queue->next;
  else {
    // If we're using MLFQ, the thread at the head of the queue
    // with the highest priority is next to run
    int i = 0;
    node_t *n = NULL;
    while (i < 5 && n == NULL) {
      n = mlfq[i]->next;
      i++;
    }

    return n;
 }
}

// Returns thread id of thread up next on CPU
// Returns -1 if the data structure is empty.
int id_of_next_thread_to_get_cpu()
{
  node_t *n = node_next_on_cpu();
  if (n)
    return n->t->id;
  else
    return -1;
}
// Returns the cond for the thread next up on the CPU
// Returns NULL if the data structure is empty
pthread_cond_t * cond_of_next_thread_to_get_cpu()
{
  node_t * n = node_next_on_cpu();
  if (n)
    return n->cond;
  else
    return NULL;
}











int schedule_me( float currentTime, int tid, int remainingTime, int tprio ) {
/**

	Fill your code here
*/
// Determine whether the current thread has a lock on the scheduler
// i.e. just ran on the CPU for some time quanta
bool just_ran_on_cpu = thread_is_on_cpu(tid);

if (just_ran_on_cpu) {
  // If we already had the lock, the current global time is equal
  // to the current time as reported by the calling thread.
  #if DEBUG == 1
    fprintf(stderr, "T%d just ran on the CPU\n", tid);
  #endif

  global_time = ceil(currentTime);

  #if DEBUG == 1
    fprintf(stderr, "T%d set global time to %d\n", tid, global_time);
  #endif
} else {
  // If not, make a new _thread_info describing the current thread.
  // Then increment the waiting count for the scheduler mutex,
  // and wait for a lock on the scheduler.
  #if DEBUG_ARRIVAL == 1
    fprintf(stderr, "T%d arrived at %f\n", tid, currentTime);
  #endif

  // If global time (according to the scheduler) is still equal to -1,
  // set it equal to the ceiling of the arrival time of the first thread
  // to run on the CPU.
  if (global_time == -1) {
    global_time = ceil(currentTime);
    if (DEBUG)
      fprintf(stderr, "Global time had not been set; now set to %d.\n",
              global_time);
  }

  inc_waiting();

  // Get scheduler lock
  if (DEBUG)
    fprintf(stderr, "T%d trying to get scheduler lock...\n", tid);

  pthread_mutex_lock(scheduler);

  if (DEBUG)
    fprintf(stderr, "T%d got scheduler lock\n", tid);
}


// If we already had the lock, the current thread is at the head of
// the queue.  We then reinsert it at its correct position, having
// already run on the CPU
node_t *n;
if (just_ran_on_cpu) {
  // If we just ran on the CPU, reinsert the head into the queue
  n = reinsert_head_into_queue(currentTime, remainingTime);
} else {
  // Otherwise, we add the new thread to the queue
  _thread_info_t *t = make_thread(currentTime, tid, remainingTime, tprio);
  n = add_new_thread_to_queue(t);
}

if (DEBUG_QUEUE)
  print_ready_queue();

// The thread has either just been added to the queue, or has just run
// for a time quanta on the CPU.  The current thread has
// the scheduler mutex lock.

// In either case, check to see if other threads need to be added to
// the ready queue
pthread_mutex_lock(waiting_count);


if (!just_ran_on_cpu) {
  // If the thread did NOT just run on the CPU, indicate
  // that the thread is no longer waiting to add itself to the queue
  // by decrementing num_waiting
  if (DEBUG)
    fprintf(stderr, "T%d no longer waiting; decrementing num_waiting from %d to %d.\n",
            tid, num_waiting, num_waiting - 1);

    num_waiting--;
}

// If other threads needed to be added, release the lock on
// scheduler to allow those threads to add themselves
if (num_waiting > 0) {
  if (DEBUG)
    fprintf(stderr, "%d other threads to add to queue; T%d releases scheduler mutex lock.\n",
            num_waiting, tid);

  pthread_mutex_unlock(waiting_count);


  if (DEBUG)
    fprintf(stderr, "T%d will wait on cond.\n", tid);

  pthread_cond_wait(n->cond, scheduler);

  if (DEBUG)
    fprintf(stderr, "T%d woken by signal; now has scheduler lock.\n", tid);
} else {
  if (DEBUG)
    fprintf(stderr, "No threads to add to queue; T%d continuing.\n", tid);

  pthread_mutex_unlock(waiting_count);
}

// Check if the current thread is up next on the CPU
// If not, signal the thread that is scheduled next
node_t *node_of_next = node_next_on_cpu();
if (n != node_of_next) {
    if (DEBUG)
      fprintf(stderr, "T%d is not next on CPU; will signal head of queue.\n", tid);

    pthread_cond_signal(node_of_next->cond);

    if (DEBUG)
      fprintf(stderr, "T%d signaled T%d to pass scheduler lock.\n",
              tid, id_of_next_thread_to_get_cpu());

    if (DEBUG)
      fprintf(stderr, "T%d will wait on cond for scheduler lock.\n", tid);

    pthread_cond_wait(n->cond, scheduler);

    if (DEBUG)
      fprintf(stderr, "T%d woken by signal; now has scheduler lock.\n", tid);
  }


// Thread is now definitely at the head of queue.


// If remainingTime == 0, thread removes itself from the queue
if (remainingTime == 0) {
    if (DEBUG)
      fprintf(stderr, "T%d has no remaining time.  Popping from queue.\n", tid);

    if (sched_type < 3)
      // If using FCFS, SRTF, or PBS, pop the ready queue
      pop_queue(ready_queue);
    else
      // Otherwise, pop the appropriate level of the mlfq
      pop_queue(mlfq[n->t->priority]);

    if (DEBUG)
      fprintf(stderr, "T%d popped from queue.\n", tid);
    if (DEBUG_QUEUE)
      print_ready_queue();

    // If there are threads to signal, signal the thread
    // scheduled next for the CPU
    node_of_next = node_next_on_cpu();
    if (node_of_next != NULL) {
      if (DEBUG)
        fprintf(stderr, "T%d signaling T%d to pass scheduler lock.\n", tid,
                node_of_next->t->id);

      pthread_cond_signal(node_of_next->cond);

      if (DEBUG)
        fprintf(stderr, "T%d has signaled T%d.\n", tid,
                id_of_next_thread_to_get_cpu());
    }

    // Finally, unlock the CPU mutex
    pthread_mutex_unlock(scheduler);
} else {
  // If not, we are scheduled to run on the CPU next,
  // so set the id of the thread on the CPU to our id.
  set_thread_on_cpu(tid);
  pthread_mutex_lock(thread_on_cpu);
  node_on_cpu = n;
  pthread_mutex_unlock(thread_on_cpu);

  if (DEBUG)
    fprintf(stderr, "T%d will now run on CPU.\n", tid);
}

// As per the project specification, return current global time
if (currentTime > (float) global_time)
  // We can't "schedule" the thread until after it has arrived,
  // so increase the global time to accomodate it
  global_time = ceil(currentTime);

return global_time;


}

int num_preemeptions(int tid){
/**

	Fill your code here
*/

  return -1;
}

float total_wait_time(int tid){
/**

	Fill your code here
*/

  return -0.1;
}
